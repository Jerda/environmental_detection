import Vue from 'vue'
import VueRouter from 'vue-router'

const register = () => import('../components/auth/register.vue');
const login = () => import('../components/auth/login.vue');
const userType = () => import('../components/auth/type.vue');

/*
 用户
 */
const user = () => import('../components/user/index.vue');
const userInfo = () => import('../components/user/info.vue');
const factoryList = () => import('../components/user/factory_list.vue');
const governor = () => import('../components/user/governor/index.vue');
const userResetPassword = () => import('../components/user/passwords/reset.vue');
const userForgotPassword = () => import('../components/user/passwords/forgot.vue');
const applyUserInfo = () => import('../components/user/governor/apply_user_info.vue');

/*
 监控
 */
const video = () => import('../components/video/index.vue');

/*
 监测
 */
const environment = () => import('../components/environment/index.vue');


let routes = [
    {
        path: '/register',
        name: 'register',
        component: register
    },
    {
        path: '/login',
        name: 'login',
        component: login
    },
    {
        path: '/user-type',
        name: 'user-type',
        component: userType
    },
    {
        path: '/',
        name: 'user',
        component: user,
        /*children: [
            {
                path: 'info',
                name: 'user-info',
                component: userInfo
            }
        ],*/
    },
    {
        path: '/userInfo',
        name: 'user-info',
        component: userInfo
    },
    {
        path: '/userResetPassword',
        name: 'user-reset-password',
        component: userResetPassword
    },
    {
        path: '/userForgotPassword',
        name: 'user-forgot-password',
        component: userForgotPassword
    },
    {
        path: '/factoryList',
        name: 'factoryList',
        component: factoryList
    },
    {
        path: '/governor',
        name: 'governor',
        component: governor
    },
    {
        path: '/apply-user-info/:user_id',
        name: 'apply-user-info',
        component: applyUserInfo
    },
    {
        path: '/video',
        name: 'video',
        component: video,
        children: [],
    },
    {
        path: '/environment',
        name: 'environment',
        component: environment,
        children: [],
    },
];

const router = new VueRouter({
    mode: 'history',
    routes,
});


export default router


